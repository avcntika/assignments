package com.example.aadassignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class courses extends AppCompatActivity {
    ListView listview;

    ArrayList<String> arr = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        listview = findViewById(R.id.listview);

        arr.add("Data Science");
        arr.add("Mechanical");
        arr.add("Electrical");
        arr.add("Computer science");
        arr.add("Civil");
        arr.add("chemical");
        arr.add("AI");
        arr.add("mathematics");
        arr.add("statistics");
        arr.add("architecture");
        arr.add("design");
        arr.add("Physics");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext()
                , android.R.layout.simple_list_item_1, arr);

        listview.setAdapter(adapter);
    }
}